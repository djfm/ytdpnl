/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
/*!*****************************************!*\
  !*** ./src/extension/content-script.ts ***!
  \*****************************************/

console.log('hello from content script in ytdpnl extension!');

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udGVudC1zY3JpcHQuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQWE7QUFDYiIsInNvdXJjZXMiOlsid2VicGFjazovL3l0ZHBubC8uL3NyYy9leHRlbnNpb24vY29udGVudC1zY3JpcHQudHMiXSwic291cmNlc0NvbnRlbnQiOlsiXCJ1c2Ugc3RyaWN0XCI7XG5jb25zb2xlLmxvZygnaGVsbG8gZnJvbSBjb250ZW50IHNjcmlwdCBpbiB5dGRwbmwgZXh0ZW5zaW9uIScpO1xuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9